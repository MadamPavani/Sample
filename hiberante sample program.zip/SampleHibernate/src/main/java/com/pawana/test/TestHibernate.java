package com.pawana.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestHibernate {

	public static void main(String[] args) {
		final SessionFactory sessionFactory;
		sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		session.beginTransaction();
		Stock stock = new Stock();

		stock.setStockCode("4716");
		stock.setStockName("GENN");

		session.save(stock);
		session.getTransaction().commit();
	}

}
